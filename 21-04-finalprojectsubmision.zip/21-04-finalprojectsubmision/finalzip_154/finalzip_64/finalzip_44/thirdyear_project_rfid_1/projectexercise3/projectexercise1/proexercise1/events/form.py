from django import forms
from .models import eventModel

TYPE_CHOISES=(
    (1,"Birthday Event"),
    (2,"Company Special Event"),
)
class eventForm(forms.ModelForm):
    eventName=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    eventType_id=forms.ChoiceField(choices=TYPE_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    eventDate = forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control','placeholder':"YYYY-MM-DD H:I:S"}))
    class Meta:
         model=eventModel
         fields=("eventName","eventType_id","eventDate")
