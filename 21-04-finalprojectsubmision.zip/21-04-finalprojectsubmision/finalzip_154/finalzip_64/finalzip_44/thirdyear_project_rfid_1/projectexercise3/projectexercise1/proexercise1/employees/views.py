from django.shortcuts import render,redirect,get_object_or_404
from .form import EmployeeForm
from django.http import JsonResponse
from accounts.models import CustomUser
from django.contrib.auth.hashers import make_password
# Create your views here.

        
             
             
# from django.shortcuts import render
# from .form import EmployeeForm
# from .models import Employees

# # Create your views here.
# def addemployees(request):
#     if request.method == "POST":
#         form = EmployeeForm(data = request.POST, files = request.FILES)
#         if form.is_valid(): 
#             form.save()
#             print("Successfully Inserted")
#             return render(request, "index.html")
#         else:
#             print("Not valide data")
#             return render(request, "addemployee.html", {"form": form})
#     else:
#         form = EmployeeForm()
#         return render(request, "addemployee.html", {'form': form})
    

# def viewemployees(request):
#     employees = Employees.objects.all()
#     return render(request, "viewemployee.html", {'employees': employees})


def viewemployee(request):
    success_msg = request.GET.get('data')
    employees=CustomUser.objects.filter(userType=3, is_active = 1)
    form=EmployeeForm()
    return render(request,"employees.html",{'employees':employees, 'form':form,'success_msg': success_msg})
 
 
# def viewemployee1(request):
#      employees=CustomUser.objects.all()
#      form=EmployeeForm()
#      return render(request,"employees.html",{'employees':employees, 'form':form})
 
def addemployee(request):
         form=EmployeeForm(data=request.POST)
         if form.is_valid():
            fname = form.cleaned_data['first_name'] 
            lname = request.POST['last_name']    
            uname = request.POST["username"]    
            email =  request.POST["email"]
            password = form.cleaned_data['password']
            department=request.POST["department"]
            designation=request.POST["designation"]
            hashed_password = make_password(password)  
            usertype=3
            user = CustomUser.objects.create_user(first_name=fname, last_name = lname, username = uname, password = hashed_password, email=email,userType=usertype,department=department,designation=designation)
            print("Inserted")
            user.save()
            print("succesfully inserted")
            messages="Employee added succesfully"
            return redirect("/employees/viewemployee")
            # return redirect('viewemployee/?data={}'.format(messages))
         else:
            print (form.errors)
            print("not validate data")
            messages="Not validate data"
            return render(request,"index.html",{'error_msg': messages}) 
 
def employee_detail(request, pk):
    employee = get_object_or_404(CustomUser, pk=pk)
    return render(request, 'employees.html', {'emp': employee})
        
def editemployee(request, pk):
    obj = get_object_or_404(CustomUser, pk=pk)
    if request.method == "POST": 
        form =EmployeeForm(data=request.POST,instance=obj)
        if form.is_valid():
            form.save()
            print("successfully updated")
            message1="Employee updated succesfully"
            employees=CustomUser.objects.filter(userType=3,is_active=1)
            form1=EmployeeForm()
            return render(request, "employees.html", {'employees':employees, 'form':form1,'message1':message1})
        else:
            print(form.errors)
            print("Not valid data")
            message1="Not validate data"
            return redirect('viewemployee/?data={}'.format(message1))
    else:
        form =EmployeeForm(instance=obj)
        return render(request, "editemployees.html", {'form': form})
       
     
def deleteemployee(request, pk):
    employee = CustomUser.objects.get(id=pk)
    employee.is_active = 0
    employee.save()
    return JsonResponse({"message": "Employees Deleted Successfully"})


    # Front end - XML Formate - Backend - XML - format(Decode)
    #                                XML Encode ----- Front end - Decode


    # Data send - Encode 
    # Data get - Decode      


    # JSON - Javascript object notation
    #         - intermidator - Object 




