
# Create your views here.
from django.shortcuts import render,redirect,get_object_or_404
from .form import holForm
from .models import holModel
from django.http import JsonResponse

# Create your views here.
def addholiday(request):
        form = holForm(data = request.POST)
        if form.is_valid(): 
            form.save()
            print("Successfully Inserted")
            return redirect("/holidays/viewholiday")
        else:
            print (form.errors)
            print("not validate data")
            return render(request,"holidays.html")
    

def viewholiday(request):
    holidays1 = holModel.objects.filter(is_active=1)
    form=holForm()
    return render(request, "holidays.html", {'holidays1': holidays1,'form':form})

def editholiday(request, pk):
    obj = get_object_or_404(holModel, pk=pk)
    if request.method == "POST": 
        form =holForm(data=request.POST,instance=obj)
        if form.is_valid():
            form.save()
            print("successfully Updated")
            holidays1=holModel.objects.filter(is_active=1)
            form1=holForm()
            return render(request, "holidays.html", {'holidays1':holidays1, 'form':form1})
        else:
            print(form.errors)
            print("Not valid data")
            return redirect('viewholiday')
    else:
        # print("Else")
        form =holForm(instance=obj)
        return render(request, "editholidays.html", {"form":form})
    
def deleteholiday(request, pk):
    holidays1 =holModel.objects.get(id=pk)
    holidays1.is_active = 0
    holidays1.save()
    return JsonResponse({"message": "holiday Deleted Successfully"})
