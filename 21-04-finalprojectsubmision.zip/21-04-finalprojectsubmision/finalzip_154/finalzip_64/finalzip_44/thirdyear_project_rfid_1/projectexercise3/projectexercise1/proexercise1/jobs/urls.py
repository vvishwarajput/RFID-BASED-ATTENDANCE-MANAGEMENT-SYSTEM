from django.urls import path
from . import views
urlpatterns = [
    path("addjob",views.addjob,name="addjob"),
    path("viewjob",views.viewjob,name="viewjob"),
    path("editjob/<int:pk>/",views.editjob,name="editjob"),
    path("deletejob/<int:pk>/",views.deletejob,name="deletejob")
]

