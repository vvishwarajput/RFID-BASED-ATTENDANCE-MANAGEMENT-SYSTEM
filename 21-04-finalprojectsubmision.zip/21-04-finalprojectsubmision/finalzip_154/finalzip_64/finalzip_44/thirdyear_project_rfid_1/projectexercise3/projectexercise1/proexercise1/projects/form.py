
from django import forms
from .models import projectModel, projectTeamModel
from clients.models import Clients
from accounts.models import CustomUser

# CLIENTS=(
#     ("Global Technologies","Global Technologies"),
#     ("Delta infotech","Delta infotech")
# )

class projectForm(forms.ModelForm):
    projectName=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    project_price= forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    client_name=forms.ModelChoiceField(queryset=Clients.objects.all(), widget=forms.Select(attrs={'class':'form-control'}), empty_label=None)
    email=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    client_address= forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    project_deadline=forms.DateField(widget=forms.DateInput(attrs={'class':'form-control', 'placeholder': "YYYY-MM-DD"}))
    # project_deadline=forms.DateField(widget=forms.DateInput(attrs={'class':'form-control', 'placeholder': "YYYY-MM-DD H:I:S"}))
    class Meta:
        model=projectModel
        fields=("projectName","project_price","client_name","email","client_address","project_deadline")

class projectTeamForm(forms.ModelForm):
    projectId = forms.ModelChoiceField(queryset=projectModel.objects.filter(is_active=1), widget=forms.Select(attrs={'class':'form-control'}))
    userId = forms.ModelChoiceField(queryset=CustomUser.objects.filter(userType=3, is_active=1), widget=forms.Select(attrs={'class':'form-control'}))
    class Meta:
        model=projectTeamModel
        fields="__all__"

    def __init__(self, *args, **kwargs):
        initial_value = kwargs.pop('initial_value', None)
        super().__init__(*args, **kwargs)
        if initial_value:
            self.fields['projectId'].initial = initial_value
