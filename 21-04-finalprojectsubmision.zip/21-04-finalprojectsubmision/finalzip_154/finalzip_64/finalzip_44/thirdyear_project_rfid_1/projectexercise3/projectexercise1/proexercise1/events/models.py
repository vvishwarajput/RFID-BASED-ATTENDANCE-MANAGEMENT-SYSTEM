from django.db import models
from django.utils.timezone import *
# Create your models here.
class eventModel(models.Model):
      eventName=models.CharField(max_length=256)
      eventDate=models.DateTimeField(default=now)     
      eventType_id=models.IntegerField()
      is_active=models.IntegerField(default=1)