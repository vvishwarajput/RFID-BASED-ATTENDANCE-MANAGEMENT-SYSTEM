
from django import forms
from .models import holModel

class holForm(forms.ModelForm):
    holiday_Name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    holiday_date= forms.DateField(widget=forms.DateInput(attrs={'class':'form-control','placeholder': "YYYY-MM-DD"}))
    
    class Meta:
        model=holModel
        fields=("holiday_Name","holiday_date")
