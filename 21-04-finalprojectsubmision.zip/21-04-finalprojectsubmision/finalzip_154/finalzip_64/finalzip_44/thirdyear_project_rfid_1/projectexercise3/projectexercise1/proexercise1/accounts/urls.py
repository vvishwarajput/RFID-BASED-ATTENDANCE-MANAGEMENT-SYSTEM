from django.urls import path
from . import views
urlpatterns = [
    path("register",views.register,name="register"),
    path("",views.login,name="login"),
    path("logout",views.logout,name="logout"),
    path("viewprofile/<int:pk>/",views.viewprofile,name="viewprofile"),
    path("editprofile/<int:pk>/",views.editprofile,name="editprofile"),
    path("resetpass",views.resetpass,name="resetpass")
]
