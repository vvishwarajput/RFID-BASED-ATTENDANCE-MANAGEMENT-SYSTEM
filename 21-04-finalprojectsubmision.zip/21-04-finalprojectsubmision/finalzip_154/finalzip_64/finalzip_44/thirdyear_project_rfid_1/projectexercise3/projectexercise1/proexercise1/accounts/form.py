from django import forms
from .models import CustomUser

DEPARTMENT_CHOISES = (
    ("web development", "web development"),
    ("IT management", "IT management"),
    ("Marketing", "Marketing")
)

DESIGNATION_CHOISES = (
    ("Web Developer", "Web Developer"),
    ("Web Designer", "Web Designer"),
    ("android developer", "android developer"),
)

GENDER_CH=(
    ("female","female"),
    ("male","male")
)
class EditprofileForm(forms.ModelForm):
    first_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    last_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    # username=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    # password=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control',"type":"password"}))
    # email=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    address=forms.CharField(widget=forms.Textarea(attrs={'class':'form-control'}))
   # pic=forms.ImageField(widget=forms.ImageField(attrs={'class':'form-control'}))
    # designation=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    country=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    department=forms.ChoiceField(choices=DEPARTMENT_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    designation=forms.ChoiceField(choices=DESIGNATION_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    # department=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    date_joined=forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control'}))
    dob=forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control'}))
    gender=forms.ChoiceField(choices=GENDER_CH,widget=forms.Select(attrs={'class':'form-control'}))
    state=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    class Meta:
        model=CustomUser
        fields=fields=("first_name", "last_name","address","country","department","designation","dob","gender","state","pic", "date_joined")