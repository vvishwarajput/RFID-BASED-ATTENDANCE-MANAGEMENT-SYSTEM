from django.urls import path
from . import views
urlpatterns = [
    path("addclient",views.addclient,name="addclient"),
    path("viewclient",views.viewclient,name="viewclient"),
    path("editclient/<int:pk>/",views.editclient,name="editclient"),
    path("deleteclient/<int:pk>/",views.deleteclient,name="deleteclient")
]

