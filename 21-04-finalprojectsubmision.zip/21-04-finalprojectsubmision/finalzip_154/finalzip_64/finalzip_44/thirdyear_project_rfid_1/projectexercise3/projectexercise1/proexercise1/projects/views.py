from django.shortcuts import render,redirect,get_object_or_404
from .form import projectForm, projectTeamForm
from .models import projectModel, projectTeamModel, CustomUser
from django.http import JsonResponse

# Create your views here.
def addproject(request):
        form = projectForm(data = request.POST)
        if form.is_valid(): 
            form.save()
            print("Successfully Inserted")
            return redirect("/projects/viewproject")
        else:
            print (form.errors)
            print("not validate data")
            return render(request,"projects.html")
    

def viewproject(request):
    projects1=projectModel.objects.filter(is_active=1)
    form=projectForm()
    return render(request, "projects.html", {'projects1': projects1,'form':form})

def viewproject1(request,pk):
    projects=projectModel.objects.filter(id__in=projectTeamModel.objects.filter(userId= pk).values('projectId'))
    projectslist=list(projects.values_list('projectName','project_deadline' ,'client_name','client_address','email','project_price','id'))
    return render(request, 'projects.html', {'projectslist': projectslist})

def editproject(request, pk):
    obj = get_object_or_404(projectModel, pk=pk)
    if request.method == "POST": 
        form =projectForm(data=request.POST,instance=obj)
        if form.is_valid():
            form.save()
            print("successfully Updated")
            projects1=projectModel.objects.filter(is_active=1)
            form1=projectForm()
            return render(request, "projects.html", {'projects1':projects1, 'form':form1})
        else:
            print(form.errors)
            print("Not valid data")
            return redirect('viewproject')
    else:
        # print("Else")
        form =projectForm(instance=obj)
        return render(request, "editprojects.html", {"form":form})
    
def addteammember(request, pk):
    if request.method == "POST": 
        form =projectTeamForm(data=request.POST)
        if form.is_valid():
            form.save()
            print("successfully Updated")
            projects1=projectModel.objects.filter(is_active=1)
            form1=projectTeamForm()
            return render(request, "projects.html", {'projects1':projects1, 'form':form1})
        else:
            print(form.errors)
            print("Not valid data")
            return redirect('viewproject')
    else:
        # print("Else")
        form = projectTeamForm(initial_value=pk)
        return render(request, "addteammember.html", {"form":form})
    

def viewteammembers(request, pk):
    projects = CustomUser.objects.filter(id__in=projectTeamModel.objects.filter(projectId = pk).values('userId'))
    user_names = list(projects.values_list('first_name', 'last_name', 'username'))
    return render(request, 'viewteammember.html', {'user_names': user_names})

def deleteproject(request, pk):
    projects1 = projectModel.objects.get(id=pk)
    projects1.is_active = 0
    projects1.save()
    return JsonResponse({"message": "project Deleted Successfully"})
