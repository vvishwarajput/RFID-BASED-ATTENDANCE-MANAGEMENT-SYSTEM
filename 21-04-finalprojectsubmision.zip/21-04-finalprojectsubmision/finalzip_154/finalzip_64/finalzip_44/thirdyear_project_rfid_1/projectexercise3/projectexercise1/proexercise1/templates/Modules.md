Employees:
    1. Dashboard
    2. Projects - Work 
    3. Events - View 
    4. Attendence - View
    5. Holiday - View 
Admin:
    1. Dashboard
    2. Projects - All
    3. Clients
    4. Events - Add/View/Edit
    5. Attendence - View
    6. Holiday - View 
HR:
    1. Dashboard
    2. Projects - All
    3. Clients - Add/Edit/View
    4. Events - Add/View/Edit
    5. Attendence - View 
    6. Jobs - Add/Edit/View
    7. Holiday - Add/Edit/View 
    8. Employees - Add/Edit/View


    1 - Birthday Event 
    2 - Company special Event
            - Annaual Day
            - 31st evening 
            - Christmas


    Events:
        Event Name, Date, Type_id - form.py choise - 
        



