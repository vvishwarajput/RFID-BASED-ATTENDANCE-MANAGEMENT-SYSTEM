
from django import forms
from .models import JobModel

DEPARTMENT_CHOISES = (
    ("Web Developemnt", "Web Development"),
    ("Application Development", "Application Development"),
    ("IT Management", "IT Management")
)

JOBTYPE_CHOISES = (
    ("Full Time", "Full Time"),
    ("Part Time", "Part Time"),
    ("Internship", "Internship"),
    ("Remote","Remote")
)

STATUS_CHOISES=(
    ("Open","Open"),
    ("Closed","Closed"),
    ("Cancelled","Cancelled")
)


class JobForm(forms.ModelForm):
    jobtitle=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    job_location=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    description=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    no_of_vacancies= forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    experience= forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    age= forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    department=forms.ChoiceField(choices=DEPARTMENT_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    expectedSalary= forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    job_type=forms.ChoiceField(choices=JOBTYPE_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    status=forms.ChoiceField(choices=STATUS_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    joining_date= forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control','placeholder': "YYYY-MM-DD H:I:S" }))
    # project_deadline=forms.DateField(widget=forms.DateInput(attrs={'class':'form-control', 'placeholder': "YYYY-MM-DD H:I:S"}))
    class Meta:
        model=JobModel
        fields=("jobtitle","job_location","description","no_of_vacancies","experience","age","department","expectedSalary", "job_type","status","joining_date")
