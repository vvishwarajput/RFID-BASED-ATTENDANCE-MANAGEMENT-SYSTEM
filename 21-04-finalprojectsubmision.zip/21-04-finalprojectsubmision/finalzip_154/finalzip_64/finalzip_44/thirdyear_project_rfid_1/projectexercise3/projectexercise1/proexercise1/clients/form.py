from django import forms
from .models import Clients

DEPARTMENT_CHOISES = (
    ("Global Technologies", "Global Technologies"),
    ("Delta Infotech", "Delta Infotech"),
    ("International Software Inc", "International Software Inc")
)

DESIGNATION_CHOISES = (
    ("CEO", "CEO"),
    ("Manager", "Manager"),
)


class ClientForm(forms.ModelForm):
    firstName = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    lastName = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    userName = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    email = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    password=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control',"type":"password"}))
    phone = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    companyName=forms.ChoiceField(choices=DEPARTMENT_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    designation=forms.ChoiceField(choices=DESIGNATION_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    class Meta:
        model=Clients
        fields=("firstName","lastName","userName","email","password","phone","companyName","designation")
        # fields=("firstname", "lastname", )
