from django.db import models
from django.utils.timezone import *

class JobModel(models.Model):
    jobtitle = models.CharField(max_length=256)
    department = models.CharField(max_length=256)
    job_location= models.CharField(max_length=256)
    no_of_vacancies= models.IntegerField()
    experience = models.IntegerField()
    age = models.IntegerField()
    expectedSalary=models.IntegerField()
    joining_date=models.DateTimeField(default=now)
    job_type=models.CharField(max_length=256)
    status=models.CharField(max_length=256)
    description=models.CharField(max_length=256)
    is_active=models.IntegerField(default=1)

