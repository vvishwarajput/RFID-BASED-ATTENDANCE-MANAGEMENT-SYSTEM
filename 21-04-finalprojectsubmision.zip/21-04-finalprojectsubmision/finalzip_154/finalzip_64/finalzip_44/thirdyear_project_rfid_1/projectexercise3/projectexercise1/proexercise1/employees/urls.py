from django.urls import path
from . import views
urlpatterns = [
    path("addemployee",views.addemployee,name="addemployee"),
    # path("viewemployee1",views.viewemployee1,name="viewemployee1"),
    path("viewemployee",views.viewemployee,name="viewemployee"),
    path("editemployee/<int:pk>/",views.editemployee,name="editemployee"),
    path("deleteemployee/<int:pk>/",views.deleteemployee,name="deleteemployee")
]
