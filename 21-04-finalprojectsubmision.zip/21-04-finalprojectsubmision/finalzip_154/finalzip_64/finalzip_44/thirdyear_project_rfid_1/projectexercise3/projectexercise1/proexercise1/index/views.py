from django.shortcuts import render
from django.http import HttpResponse
from attendence.models import Attendance
from clients.models import Clients
from projects.models import projectModel
from accounts.models import CustomUser

# Create your views here.
def index(request):
    success_msg = request.GET.get('data')
    total_clients = Clients.objects.filter(is_active=1).count()
    total_emp=CustomUser.objects.filter(is_active=1,userType=3).count()
    project_total=projectModel.objects.filter(is_active=1).count()
    projects=projectModel.objects.filter(is_active=1)
    clients = Clients.objects.filter(is_active=1)

    userId = request.user.id
    getUser = CustomUser.objects.get(id=userId)
    cardId = getUser.cardId
    attendanceData = Attendance.objects.filter(card_id=cardId)
  
    attendance_records = Attendance.objects.filter(card_id=cardId).order_by('punch_time')

    total_hours = 0
    last_punch_type = ''

    for attendance in attendance_records:
        if attendance.punch_type == 'in':
            last_punch_type = 'in'
            last_punch_time = attendance.punch_time
        elif attendance.punch_type == 'out' and last_punch_type == 'in':
            total_hours += (attendance.punch_time - last_punch_time).total_seconds() / 3600
            last_punch_type = 'out'

    total_hours = round(total_hours, 2)
    first_records = Attendance.objects.filter(card_id=cardId).first()

    return render(request,'index.html', {'total_clients': total_clients, 'clients': clients,'project_total':project_total,'projects':projects,'total_emp':total_emp, 'success_msg': success_msg, 'attendanceData': attendanceData, 'total_hours': total_hours, 'first_records':first_records})
