from django.urls import path
from . import views
urlpatterns = [
   path("viewattendance",views.viewattendance,name="viewattendance"),
   path("importattendence",views.import_attendance_data,name="importattendence"),
]
