from django.shortcuts import render
import os
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from django.core.exceptions import ValidationError
from .models import Attendance
from .models import CustomUser as User
from django.db.models import Sum, F, ExpressionWrapper, fields

# # Create your views here.
def viewattendance(request):
    userId = request.user.id
    getUser = User.objects.get(id=userId)
    cardId = getUser.cardId
    attendanceData = Attendance.objects.filter(card_id=cardId)
  
    attendance_records = Attendance.objects.filter(card_id=cardId).order_by('punch_time')

    total_hours = 0
    last_punch_type = ''

    for attendance in attendance_records:
        if attendance.punch_type == 'in':
            last_punch_type = 'in'
            last_punch_time = attendance.punch_time
        elif attendance.punch_type == 'out' and last_punch_type == 'in':
            total_hours += (attendance.punch_time - last_punch_time).total_seconds() / 3600
            last_punch_type = 'out'

    total_hours = round(total_hours, 2)
    first_records = Attendance.objects.filter(card_id=cardId).first()
    print(first_records)
    return render(request,"attendance-employee.html", {'attendanceData': attendanceData, 'total_hours': total_hours, 'first_records':first_records})

def import_attendance_data(request):
    file_name = 'attendenceData.txt'
    base_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(base_dir, file_name)
    with open(file_path, 'r') as file:
        lines = file.readlines()
    for line in lines:
        card_id = line.strip()
        attendance = Attendance.objects.filter(card_id=card_id).order_by('-punch_time').first()
        if attendance and attendance.punch_type == 'in':
            attendance = Attendance(card_id=card_id, punch_type='out')
        else:
            attendance = Attendance(card_id=card_id, punch_type='in')
        try:
            attendance.full_clean()
            attendance.save()
            clean_file(file_path)
        except ValidationError as e:
            # Handle validation error
            pass

    return render(request,"index.html")

def clean_file(file_path):
    with open(file_path, 'w') as file:
        file.write('')