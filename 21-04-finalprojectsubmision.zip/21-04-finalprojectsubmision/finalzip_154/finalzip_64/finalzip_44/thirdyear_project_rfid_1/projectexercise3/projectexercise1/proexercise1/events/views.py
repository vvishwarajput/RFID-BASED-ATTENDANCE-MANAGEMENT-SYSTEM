from django.shortcuts import render,redirect,get_object_or_404
from .form import eventForm
from .models import eventModel
from django.http import JsonResponse

# Create your views here.
def addevent(request):
        form = eventForm(data = request.POST)
        if form.is_valid(): 
            form.save()
            print("Successfully Inserted")
            return redirect("/events/viewevent")
        else:
            print (form.errors)
            print("not validate data")
            return render(request,"events.html")
 
 
def editevent(request, pk):
    obj = get_object_or_404(eventModel, pk=pk)
    if request.method == "POST": 
        form = eventForm(data=request.POST,instance=obj)
        if form.is_valid():
            form.save()
            print("successfully Updated")
            events1=eventModel.objects.filter(is_active=1)
            form1=eventForm()
            return render(request, "events.html", {'events1':events1, 'form':form1})
        else:
            print(form.errors)
            print("Not valid data")
            return redirect('viewevent')
    else:
        # print("Else")
        form =eventForm(instance=obj)
        return render(request, "editevents.html", {"form":form})
       

def viewevent(request):
    events1 = eventModel.objects.filter(is_active=1)
    form=eventForm()
    return render(request, "events.html", {'events1': events1,'form':form})

def deleteevent(request, pk):
    events1 = eventModel.objects.get(id=pk)
    events1.is_active = 0
    events1.save()
    return JsonResponse({"message": "event Deleted Successfully"})

