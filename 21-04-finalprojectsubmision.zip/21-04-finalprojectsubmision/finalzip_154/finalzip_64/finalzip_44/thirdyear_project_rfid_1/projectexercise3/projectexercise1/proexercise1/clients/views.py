from django.shortcuts import render,redirect,get_object_or_404
from .form import ClientForm
from .models import Clients
from django.http import JsonResponse 
# Create your views here.
def addclient(request):
        form = ClientForm(data = request.POST)
        if form.is_valid(): 
            form.save()
            print("Successfully Inserted")
            return redirect("/clients/viewclient")
        else:
            print (form.errors)
            print("not validate data")
            return render(request,"index.html")
    

def viewclient(request):
    clients1 = Clients.objects.filter(is_active=1)
    form=ClientForm()
    return render(request, "clients.html", {'clients1': clients1,'form':form})


def editclient(request, pk):
    obj = get_object_or_404(Clients, pk=pk)
    if request.method == "POST": 
        form =ClientForm(data=request.POST,instance=obj)
        if form.is_valid():
            form.save()
            print("successfully Updated")
            clients1=Clients.objects.filter(is_active=1)
            form1=ClientForm()
            return render(request, "clients.html", {'clients1':clients1, 'form':form1})
        else:
            print(form.errors)
            print("Not valid data")
            return redirect('viewclient')
    else:
        # print("Else")
        form =ClientForm(instance=obj)
        return render(request, "editclients.html", {"form":form})
    
def deleteclient(request, pk):
    client = Clients.objects.get(id=pk)
    client.is_active = 0
    client.save()
    return JsonResponse({"message": "client Deleted Successfully"})
     
