from django.contrib import admin
from .models import ty

# Register your models here.
admin.site.register(ty)
