from django.db import models
from django.utils.timezone import *
from accounts.models import CustomUser


class projectModel(models.Model):
      projectName=models.CharField(max_length=256)
      project_price=models.IntegerField()
      client_name=models.CharField(max_length=256)
      email=models.CharField(max_length=128)
      client_address=models.TextField()
      project_deadline=models.DateField()
      is_active=models.IntegerField(default=1)
    
      def __str__(self) -> str:
            return self.projectName


class projectTeamModel(models.Model):
      projectId = models.ForeignKey(projectModel, on_delete=models.CASCADE)
      userId = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    

