from django.shortcuts import render,redirect,get_object_or_404
from .form import JobForm
from .models import JobModel
from django.http import JsonResponse

# Create your views here.
def addjob(request):
        form = JobForm(data = request.POST)
        if form.is_valid(): 
            form.save()
            print("Successfully Inserted")
            return redirect("/jobs/viewjob")
        else:
            print (form.errors)
            print("not validate data")
            return render(request,"jobs.html")
    

def viewjob(request):
    jobs1 = JobModel.objects.filter(is_active=1)
    form=JobForm()
    return render(request, "jobs.html", {'jobs1': jobs1,'form':form})

def editjob(request, pk):
    obj = get_object_or_404(JobModel,pk=pk)
    if request.method == "POST": 
        form =JobForm(data=request.POST,instance=obj)
        if form.is_valid():
            form.save()
            print("successfully Updated")
            jobs1=JobModel.objects.filter(is_active=1)
            form1=JobForm()
            return render(request, "jobs.html", {'jobs1':jobs1, 'form':form1})
        else:
            print(form.errors)
            print("Not valid data")
            return redirect('viewjob')
    else:
        # print("Else")
        form =JobForm(instance=obj)
        return render(request, "editjobs.html", {"form":form})

def deletejob(request, pk):
    jobs1 = JobModel.objects.get(id=pk)
    jobs1.is_active = 0
    jobs1.save()
    return JsonResponse({"message": "job Deleted Successfully"})