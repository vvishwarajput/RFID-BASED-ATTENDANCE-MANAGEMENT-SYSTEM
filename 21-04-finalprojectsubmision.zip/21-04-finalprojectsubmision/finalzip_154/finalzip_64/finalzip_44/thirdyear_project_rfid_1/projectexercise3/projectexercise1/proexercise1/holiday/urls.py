from django.urls import path
from . import views
urlpatterns = [
    path("addholiday",views.addholiday,name="addholiday"),
    path("viewholiday",views.viewholiday,name="viewholiday"),
    path("editholiday/<int:pk>/",views.editholiday,name="editholiday"),
    path("deleteholiday/<int:pk>/",views.deleteholiday,name="deleteholiday")
]

