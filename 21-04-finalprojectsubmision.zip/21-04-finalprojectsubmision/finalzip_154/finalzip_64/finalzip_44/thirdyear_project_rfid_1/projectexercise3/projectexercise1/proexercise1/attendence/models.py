from django.db import models
from accounts.models import CustomUser

# Create your models here.
class Attendance(models.Model):
    card_id = models.CharField(max_length=10)
    punch_time = models.DateTimeField(auto_now_add=True)
    punch_type = models.CharField(max_length=10)
  