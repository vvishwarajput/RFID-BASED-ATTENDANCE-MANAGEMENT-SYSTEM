from django.urls import path
from . import views
urlpatterns = [
    path("addevent",views.addevent,name="addevent"),
    path("viewevent",views.viewevent,name="viewevent"),
    path("editevent/<int:pk>/",views.editevent,name="editevent"),
    path("deleteevent/<int:pk>/",views.deleteevent,name="deleteevent")
]
