
from django import forms
from accounts.models import CustomUser

DEPARTMENT_CHOISES = (
    ("Admin", "Admin"),
    ("Cloud", "Cloud"),
    ("HR", "HR")
)

DESIGNATION_CHOISES = (
    ("Web Developer", "Web Developer"),
    ("Web Designer", "Web Designer"),
    ("HR", "HR"),
)


class EmployeeForm(forms.ModelForm):
    first_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    last_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    username=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    email=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    password=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control',"type":"password"}))
    # empid=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    userType = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control', "type":"hidden", "value": "3"}))
    department=forms.ChoiceField(choices=DEPARTMENT_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    designation=forms.ChoiceField(choices=DESIGNATION_CHOISES,widget=forms.Select(attrs={'class':'form-control'}))
    # date_joined = forms.DateTimeField(widget=forms.DateTimeInput(attrs={'class':'form-control','placeholder': "YYYY-MM-DD H:I:S"}))
    class Meta:
        model=CustomUser
        fields=("first_name","last_name","username","email","password","userType","department","designation")