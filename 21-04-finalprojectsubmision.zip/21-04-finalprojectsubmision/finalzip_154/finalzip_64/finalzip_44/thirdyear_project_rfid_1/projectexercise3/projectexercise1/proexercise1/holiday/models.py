from django.db import models
from django.utils.timezone import *

class holModel(models.Model):
    holiday_Name= models.CharField(max_length=256)
    holiday_date=models.DateField()
    is_active=models.IntegerField(default=1)


