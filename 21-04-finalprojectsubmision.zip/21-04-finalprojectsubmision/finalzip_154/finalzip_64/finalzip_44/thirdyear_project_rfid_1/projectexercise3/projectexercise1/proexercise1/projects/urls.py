from django.urls import path
from . import views
urlpatterns = [
    path("addproject",views.addproject,name="addproject"),
    path("viewproject",views.viewproject,name="viewproject"),
    path("viewproject1/<int:pk>/",views.viewproject1,name="viewproject1"),
    path("editproject/<int:pk>/",views.editproject,name="editproject"),
    path("deleteproject/<int:pk>/",views.deleteproject,name="deleteproject"),
    path("addteammember/<int:pk>/",views.addteammember,name="addteammember"),
    path("viewteammembers/<int:pk>/",views.viewteammembers,name="viewteammember"),
]

