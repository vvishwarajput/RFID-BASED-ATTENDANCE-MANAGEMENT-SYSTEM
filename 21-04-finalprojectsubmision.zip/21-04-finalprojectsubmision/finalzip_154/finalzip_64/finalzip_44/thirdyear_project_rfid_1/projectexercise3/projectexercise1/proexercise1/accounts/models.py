from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.timezone import *
# Create your models here.
class CustomUser(AbstractUser):
    address=models.TextField(max_length=1056)
    pic=models.ImageField(upload_to="pic")
    designation=models.CharField(max_length=256)
    country=models.CharField(max_length=256)
    department=models.CharField(max_length=256)
    dob=models.DateTimeField(default=now)
    gender=models.CharField(max_length=256)
    state=models.CharField(max_length=256)
    empid=models.IntegerField()
    userType=models.IntegerField()
    cardId = models.TextField(max_length=10, default="")