# from django.shortcuts import render, redirect
# from django.contrib.auth.models import User, auth

# # Create your views here.
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.models import auth
from .form import EditprofileForm
from .models import CustomUser as User
from django.contrib import messages

def register(request):
     if request.method == "POST":
         fname = request.POST["fname"]    
         lname = request.POST["lname"]    
         uname = request.POST["uname"]    
         email =  request.POST["email"]
         password = request.POST["password"]    
         confpassword = request.POST["rpassword"]
         usertype=2
         user = User.objects.create_user(first_name=fname, last_name = lname, username = uname, password = password, email=email,userType=usertype)
         print("Inserted")
         user.save()
         return redirect("/")
     else:
         return render(request, "register.html")  
     
     
def login(request):
    if(request.method=="POST"):
       uname=request.POST["username"]
    #    email=request.POST["email"]
       password=request.POST["password"]
       user=auth.authenticate(username=uname,password=password)
       print(user)
       if user is not None:
           auth.login(request,user)
           print("successfully logged in")
           messages = "Login Successfully!"
           return redirect('/index/?data={}'.format(messages))
       else:
           print("invalid credentials")
           messages = "Login Not Successfully!"
           return render(request, "login.html", {'error_msg': messages})
    else:
        return render(request,"login.html")
    
def logout(request):
     auth.logout(request)
     return redirect("/")
        

def editprofile(request, pk):
    obj = get_object_or_404(User, pk=pk)
    form = EditprofileForm(data=request.POST, files=request.FILES, instance=obj)
    if form.is_valid():
        form.save()
        print("successfully inserted")
        return redirect("viewprofile", pk=pk)
    else:
        print(form.errors)
        print("not valid data")
        return render(request, "profile.html", {'form': form})
          
def viewprofile(request,pk):
        obj=get_object_or_404(User,pk=pk)
        form = EditprofileForm(instance=obj)
        return render(request,"profile.html",{'form':form})
    
def resetpass(request):
    return render(request,"resetpass.html")